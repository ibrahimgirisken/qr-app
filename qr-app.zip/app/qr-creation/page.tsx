import ClientForm from './client-form'

function QrCreationPage() {
  return (
    <div className="flex items-center justify-center">
      <ClientForm/>
    </div>
  )
}

export default QrCreationPage