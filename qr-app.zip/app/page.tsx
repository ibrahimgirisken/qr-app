import QrCreationForm from "./qr-creation/client-form";


export default function QrCreationPage() {
  return (
    <div className="box-item">
      <QrCreationForm />
    </div>
  );
}